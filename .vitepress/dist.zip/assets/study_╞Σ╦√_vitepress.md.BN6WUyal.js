import{_ as n,c as a,o as p,ag as e}from"./chunks/framework.Ds6Eueu6.js";const k=JSON.parse('{"title":"","description":"","frontmatter":{},"headers":[],"relativePath":"study/其他/vitepress.md","filePath":"study/其他/vitepress.md","lastUpdated":1743231622000}'),i={name:"study/其他/vitepress.md"};function t(l,s,c,r,d,o){return p(),a("div",null,s[0]||(s[0]=[e(`<div class="language-sh vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">sh</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span style="--shiki-light:#6F42C1;--shiki-dark:#B392F0;">yarn</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> add</span><span style="--shiki-light:#005CC5;--shiki-dark:#79B8FF;"> -D</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> vitepress</span></span>
<span class="line"><span style="--shiki-light:#6F42C1;--shiki-dark:#B392F0;">yarn</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> vitepress</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> init</span></span></code></pre></div><div class="language-text vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">text</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span>┌  Welcome to VitePress!</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Where should VitePress initialize the config?</span></span>
<span class="line"><span>│  ./docs</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Where should VitePress look for your markdown files?</span></span>
<span class="line"><span>│  ./docs</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Site title:</span></span>
<span class="line"><span>│  My Awesome Project </span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Site description:</span></span>
<span class="line"><span>│  A VitePress Site</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Theme:</span></span>
<span class="line"><span>│  Default Theme</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Use TypeScript for config and theme files?</span></span>
<span class="line"><span>│  No</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Add VitePress npm scripts to package.json?</span></span>
<span class="line"><span>│  Yes</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Add a prefix for VitePress npm scripts?</span></span>
<span class="line"><span>│  Yes</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>◇  Prefix for VitePress npm scripts:</span></span>
<span class="line"><span>│  docs</span></span>
<span class="line"><span>│</span></span>
<span class="line"><span>└  Done! Now run pnpm run docs:dev and start writing.</span></span></code></pre></div><div class="language-sh vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">sh</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span style="--shiki-light:#6F42C1;--shiki-dark:#B392F0;">yarn</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> docs:dev</span></span></code></pre></div>`,3)]))}const g=n(i,[["render",t]]);export{k as __pageData,g as default};
