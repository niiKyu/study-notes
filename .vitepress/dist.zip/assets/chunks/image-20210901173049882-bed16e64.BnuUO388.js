const e="/assets/image-20210901173049882-bed16e64.AWztFeOn.png";export{e as _};
